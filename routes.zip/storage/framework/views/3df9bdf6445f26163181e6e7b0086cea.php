<footer class="bg-blue-900 text-white py-10">
  <div class="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8">
    <div class="flex flex-col items-top">
        <a href="<?php echo e(route('home')); ?>" class="flex items-top">
            <span class="text-2xl font-bold bg-gradient-to-r from-sky-500 via-emerald-500 via-55% to-yellow-500 to-95% bg-clip-text text-transparent"><?php echo e($general_setting->institute_initialism); ?></span>
        </a>
        <span class="text-md font-bold text-white-400 mt-1 mb-2"><?php echo e($general_setting->institute_name); ?></span>
        <span class="text-sm font-semibold text-white-400 mb-2"><?php echo e($general_setting->institute_motto); ?></span>
    </div>

    <!-- Redes Sociales -->
    <div>
      <h2 class="text-xl font-semibold mb-4 text-white">Conectá con nosotros</h2>
      <div class="flex gap-x-6 mb-4">
        <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e($social['href']); ?>" class="<?php echo e($social['class']); ?>" aria-label="<?php echo e($social['name']); ?>">
            <i class="fab <?php echo e($social['icon']); ?> text-2xl"></i>
          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="flex flex-col gap-y-4">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e($datum['href']); ?>" class="text-white-400">
            <?php if(!empty($datum['icon'])): ?><i class="fas <?php echo e($datum['icon']); ?> text-xl mr-2"></i><?php endif; ?><?php echo e($datum['name']); ?>

          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>

    <!-- Enlaces Rápidos -->
    <div>
      <h2 class="text-xl font-semibold mb-4 text-white">Enlaces rápidos</h2>
      <ul class="space-y-2 text-white-300">
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e($item['url']); ?>" class="<?php if($item['active']): ?> font-bold <?php endif; ?> hover:text-blue-200"><?php echo e($item['name']); ?></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>

  </div>
</footer>
<?php /**PATH H:\php\herd\isft238\resources\views/components/public/footer.blade.php ENDPATH**/ ?>