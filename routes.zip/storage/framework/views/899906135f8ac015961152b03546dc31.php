<?php if (isset($component)) { $__componentOriginala436fdf7f6a85c098c24f36f65aa4b7e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala436fdf7f6a85c098c24f36f65aa4b7e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-forms::components.field-wrapper.index','data' => ['id' => $getId(),'label' => $getLabel(),'labelSrOnly' => $isLabelHidden(),'helperText' => $getHelperText(),'hint' => $getHint(),'hintIcon' => $getHintIcon(),'required' => $isRequired(),'statePath' => $getStatePath(),'class' => '-mt-3 filament-seo-slug-input-wrapper']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-forms::field-wrapper.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getId()),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getLabel()),'label-sr-only' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isLabelHidden()),'helper-text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getHelperText()),'hint' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getHint()),'hint-icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getHintIcon()),'required' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isRequired()),'state-path' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getStatePath()),'class' => '-mt-3 filament-seo-slug-input-wrapper']); ?>
    <div
        x-data="{
            context: '<?php echo e($getContext()); ?>', // edit or create
            state: $wire.entangle('<?php echo e($getStatePath()); ?>'), // current slug value
            statePersisted: '', // slug value received from db
            stateInitial: '', // slug value before modification
            editing: false,
            modified: false,
            initModification: function() {

                this.stateInitial = this.state;

                if(!this.statePersisted) {
                    this.statePersisted = this.state;
                }

                this.editing = true;

                setTimeout(() => $refs.slugInput.focus(), 75);
                

            },
            submitModification: function() {

                if(!this.stateInitial) {
                    this.state = '';
                }
                else {
                    this.state = this.stateInitial;
                }

                $wire.set('<?php echo e($getStatePath()); ?>', this.state)

                this.detectModification();

                this.editing = false;

           },
           cancelModification: function() {

                this.stateInitial = this.state;

                this.detectModification();

                this.editing = false;

           },
           resetModification: function() {

                this.stateInitial = this.statePersisted;

                this.detectModification();

           },
           detectModification: function() {

                this.modified = this.stateInitial !== this.statePersisted;

           },
        }"
        x-on:submit.document="modified = false"
    >

        <div
            <?php echo e($attributes->merge($getExtraAttributes())->class(['flex gap-4 items-center justify-between group text-sm filament-forms-text-input-component'])); ?>

        >

            <!--[if BLOCK]><![endif]--><?php if($getReadOnly()): ?>

                <span class="flex">
                    <span class="mr-1"><?php echo e($getLabelPrefix()); ?></span>
                    <span class="text-gray-400"><?php echo e($getFullBaseUrl()); ?></span>
                    <span class="text-gray-400 font-semibold"><?php echo e($getState()); ?></span>
                </span>

                <!--[if BLOCK]><![endif]--><?php if($getSlugInputUrlVisitLinkVisible()): ?>

                <?php if (isset($component)) { $__componentOriginal549c94d872270b69c72bdf48cb183bc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal549c94d872270b69c72bdf48cb183bc9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.link','data' => ['href' => $getRecordUrl(),'target' => '_blank','size' => 'sm','icon' => 'heroicon-m-arrow-top-right-on-square','iconPosition' => 'after']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getRecordUrl()),'target' => '_blank','size' => 'sm','icon' => 'heroicon-m-arrow-top-right-on-square','icon-position' => 'after']); ?>
                    <?php echo e($getVisitLinkLabel()); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $attributes = $__attributesOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $component = $__componentOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__componentOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <?php else: ?>

                <span class="flex items-center gap-1">

                    <span><?php echo e($getLabelPrefix()); ?></span>

                    <div class="flex items-center gap-0">
                        <span
                            x-text="!editing ? '<?php echo e($getFullBaseUrl()); ?>' : '<?php echo e($getBasePath()); ?>'"
                            class="text-gray-400"
                        ></span>
                        <a
                            href="#"
                            role="button"
                            title="<?php echo e(trans('filament-title-with-slug::package.permalink_action_edit')); ?>"
                            x-on:click.prevent="initModification()"
                            x-show="!editing"
                            class="
                                cursor-pointer
                                font-semibold text-gray-400
                                inline-flex items-center justify-center
                                hover:underline hover:text-primary-500
                                dark:hover:text-primary-400
                                gap-1
                            "
                            :class="context !== 'create' && modified ? 'text-gray-600 bg-gray-100 dark:text-gray-400 dark:bg-gray-700 px-1 rounded-md' : ''"
                        >
                            <span class="mr-1"><?php echo e($getState()); ?></span>

                            <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-m-pencil-square'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['stroke-width' => '2','class' => '
                                    h-4 w-4
                                    text-primary-600 dark:text-primary-400
                                ']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>

                            <span class="sr-only"><?php echo e(trans('filament-title-with-slug::package.permalink_action_edit')); ?></span>

                        </a>
                    </div>

                    <!--[if BLOCK]><![endif]--><?php if($getSlugLabelPostfix()): ?>
                    <span
                        x-show="!editing"
                        class="ml-0.5 text-gray-400"
                    ><?php echo e($getSlugLabelPostfix()); ?></span>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <span x-show="!editing && context !== 'create' && modified"> [<?php echo e(trans('filament-title-with-slug::package.permalink_status_changed')); ?>]</span>

                </span>

                <div
                    class="flex-1 mx-2"
                    x-show="editing"
                    style="display: none;"
                >

                <div class="flex overflow-hidden transition duration-75 bg-white rounded-lg shadow-sm fi-input-wrapper ring-1 focus-within:ring-2 dark:bg-white/5 ring-gray-950/10 focus-within:ring-primary-600 dark:ring-white/20 dark:focus-within:ring-primary-500 fi-fo-text-input">
                        <input
                            type="text"
                            x-ref="slugInput"
                            x-model="stateInitial"
                            x-bind:disabled="!editing"
                            x-on:keydown.enter="submitModification()"
                            x-on:keydown.escape="cancelModification()"
                            <?php echo ($autocomplete = $getAutocomplete()) ? "autocomplete=\"{$autocomplete}\"" : null; ?>

                            id="<?php echo e($getId()); ?>"
                            <?php echo ($placeholder = $getPlaceholder()) ? "placeholder=\"{$placeholder}\"" : null; ?>

                            <?php echo $isRequired() ? 'required' : null; ?>

                            <?php echo e($getExtraInputAttributeBag()->class([
                                'fi-input block w-full border-none bg-transparent py-1.5 text-base text-gray-950 outline-none transition duration-75 placeholder:text-gray-400 focus:ring-0 disabled:text-gray-500 disabled:[-webkit-text-fill-color:theme(colors.gray.500)] disabled:placeholder:[-webkit-text-fill-color:theme(colors.gray.400)] dark:text-white dark:placeholder:text-gray-500 dark:disabled:text-gray-400 dark:disabled:[-webkit-text-fill-color:theme(colors.gray.400)] dark:disabled:placeholder:[-webkit-text-fill-color:theme(colors.gray.500)] sm:text-xs sm:leading-6 ps-3 pe-3',
                                'border-danger-600 ring-danger-600' => $errors->has($getStatePath())])); ?>

                        />
                    </div>

                </div>

                <div
                    x-show="editing"
                    class="flex space-x-2 gap-2"
                    style="display: none;"
                >

                    <a
                        href="#"
                        role="button"
                        x-on:click.prevent="submitModification()"
                        style="--c-400:var(--primary-400);--c-500:var(--primary-500);--c-600:var(--primary-600);"
                        class="
                        fi-btn fi-btn-size-md relative grid-flow-col items-center justify-center font-semibold outline-none transition duration-75 focus:ring-2 disabled:pointer-events-none disabled:opacity-70 rounded-lg fi-btn-color-primary gap-1.5 px-3 py-2 text-sm inline-grid shadow-sm bg-custom-600 text-white hover:bg-custom-500 dark:bg-custom-500 dark:hover:bg-custom-400 focus:ring-custom-500/50 dark:focus:ring-custom-400/50 fi-ac-btn-action
                        "
                    >
                        <?php echo e(trans('filament-title-with-slug::package.permalink_action_ok')); ?>

                    </a>

                    <?php if (isset($component)) { $__componentOriginal549c94d872270b69c72bdf48cb183bc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal549c94d872270b69c72bdf48cb183bc9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.link','data' => ['xShow' => 'context === \'edit\' && modified','xOn:click.prevent' => 'resetModification()','class' => 'cursor-pointer ml-4','icon' => 'heroicon-o-arrow-path','color' => 'gray','size' => 'sm','title' => ''.e(trans('filament-title-with-slug::package.permalink_action_reset')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-show' => 'context === \'edit\' && modified','x-on:click.prevent' => 'resetModification()','class' => 'cursor-pointer ml-4','icon' => 'heroicon-o-arrow-path','color' => 'gray','size' => 'sm','title' => ''.e(trans('filament-title-with-slug::package.permalink_action_reset')).'']); ?>
                        <span class="sr-only"><?php echo e(trans('filament-title-with-slug::package.permalink_action_reset')); ?></span>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $attributes = $__attributesOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $component = $__componentOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__componentOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginal549c94d872270b69c72bdf48cb183bc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal549c94d872270b69c72bdf48cb183bc9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.link','data' => ['xOn:click.prevent' => 'cancelModification()','class' => 'cursor-pointer','icon' => 'heroicon-o-x-mark','color' => 'gray','size' => 'sm','title' => ''.e(trans('filament-title-with-slug::package.permalink_action_cancel')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click.prevent' => 'cancelModification()','class' => 'cursor-pointer','icon' => 'heroicon-o-x-mark','color' => 'gray','size' => 'sm','title' => ''.e(trans('filament-title-with-slug::package.permalink_action_cancel')).'']); ?>
                        <span class="sr-only"><?php echo e(trans('filament-title-with-slug::package.permalink_action_cancel')); ?></span>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $attributes = $__attributesOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $component = $__componentOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__componentOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>

                </div>

                <span
                    x-show="context === 'edit'"
                    class="flex items-center space-x-2"
                >

                    <!--[if BLOCK]><![endif]--><?php if($getSlugInputUrlVisitLinkVisible()): ?>
                        <template x-if="!editing">
                            <?php if (isset($component)) { $__componentOriginal549c94d872270b69c72bdf48cb183bc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal549c94d872270b69c72bdf48cb183bc9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.link','data' => ['href' => $getRecordUrl(),'target' => '_blank','size' => 'sm','icon' => 'heroicon-m-arrow-top-right-on-square','iconPosition' => 'after']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getRecordUrl()),'target' => '_blank','size' => 'sm','icon' => 'heroicon-m-arrow-top-right-on-square','icon-position' => 'after']); ?>
                                <?php echo e($getVisitLinkLabel()); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $attributes = $__attributesOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $component = $__componentOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__componentOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>
                        </template>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            </span>

            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala436fdf7f6a85c098c24f36f65aa4b7e)): ?>
<?php $attributes = $__attributesOriginala436fdf7f6a85c098c24f36f65aa4b7e; ?>
<?php unset($__attributesOriginala436fdf7f6a85c098c24f36f65aa4b7e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala436fdf7f6a85c098c24f36f65aa4b7e)): ?>
<?php $component = $__componentOriginala436fdf7f6a85c098c24f36f65aa4b7e; ?>
<?php unset($__componentOriginala436fdf7f6a85c098c24f36f65aa4b7e); ?>
<?php endif; ?>
<?php /**PATH H:\php\herd\isft238\resources\views/vendor/filament-title-with-slug/forms/fields/slug-input.blade.php ENDPATH**/ ?>