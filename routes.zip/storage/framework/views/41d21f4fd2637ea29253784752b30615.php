<?php $__env->startSection('content'); ?>
    <header class="bg-green-700 text-white py-16">
        <div class="container mx-auto px-4 text-center">
        <h1 class="text-4xl md:text-5xl font-bold">Nuestras Carreras</h1>
        <p class="mt-2 text-lg">Formación técnica superior con orientación práctica y salida laboral</p>
        </div>
    </header>
    <?php if (isset($component)) { $__componentOriginal3bc89efa5f8fbcc94b64f99d55bab5da = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3bc89efa5f8fbcc94b64f99d55bab5da = $attributes; } ?>
<?php $component = App\View\Components\Public\CareersList::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public.careers-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Public\CareersList::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3bc89efa5f8fbcc94b64f99d55bab5da)): ?>
<?php $attributes = $__attributesOriginal3bc89efa5f8fbcc94b64f99d55bab5da; ?>
<?php unset($__attributesOriginal3bc89efa5f8fbcc94b64f99d55bab5da); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3bc89efa5f8fbcc94b64f99d55bab5da)): ?>
<?php $component = $__componentOriginal3bc89efa5f8fbcc94b64f99d55bab5da; ?>
<?php unset($__componentOriginal3bc89efa5f8fbcc94b64f99d55bab5da); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public.page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\php\herd\isft238\resources\views/careers.blade.php ENDPATH**/ ?>