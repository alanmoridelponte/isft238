<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($general_setting->institute_initialism); ?> - <?php echo e($general_setting->institute_name); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css ">
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
    html {
        font-family: Rubik, sans-serif!important;
    }
    </style>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldContent('header'); ?>
</head>
<body class="bg-gray-50">
    <main class="min-h-screen flex flex-col justify-between">
        <?php if (isset($component)) { $__componentOriginale6e32b002468928371622ec6e016f311 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6e32b002468928371622ec6e016f311 = $attributes; } ?>
<?php $component = App\View\Components\Public\Banner::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public.banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Public\Banner::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6e32b002468928371622ec6e016f311)): ?>
<?php $attributes = $__attributesOriginale6e32b002468928371622ec6e016f311; ?>
<?php unset($__attributesOriginale6e32b002468928371622ec6e016f311); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6e32b002468928371622ec6e016f311)): ?>
<?php $component = $__componentOriginale6e32b002468928371622ec6e016f311; ?>
<?php unset($__componentOriginale6e32b002468928371622ec6e016f311); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginale2fc3ad2301b94c4ee7cdd2ba71c8cd7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2fc3ad2301b94c4ee7cdd2ba71c8cd7 = $attributes; } ?>
<?php $component = App\View\Components\Public\NavBar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public.nav-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Public\NavBar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2fc3ad2301b94c4ee7cdd2ba71c8cd7)): ?>
<?php $attributes = $__attributesOriginale2fc3ad2301b94c4ee7cdd2ba71c8cd7; ?>
<?php unset($__attributesOriginale2fc3ad2301b94c4ee7cdd2ba71c8cd7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2fc3ad2301b94c4ee7cdd2ba71c8cd7)): ?>
<?php $component = $__componentOriginale2fc3ad2301b94c4ee7cdd2ba71c8cd7; ?>
<?php unset($__componentOriginale2fc3ad2301b94c4ee7cdd2ba71c8cd7); ?>
<?php endif; ?>
        <div class="flex-grow">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php if (isset($component)) { $__componentOriginal890ea597e738b5ea559a49d7ff2a5a2b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal890ea597e738b5ea559a49d7ff2a5a2b = $attributes; } ?>
<?php $component = App\View\Components\Public\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Public\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal890ea597e738b5ea559a49d7ff2a5a2b)): ?>
<?php $attributes = $__attributesOriginal890ea597e738b5ea559a49d7ff2a5a2b; ?>
<?php unset($__attributesOriginal890ea597e738b5ea559a49d7ff2a5a2b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal890ea597e738b5ea559a49d7ff2a5a2b)): ?>
<?php $component = $__componentOriginal890ea597e738b5ea559a49d7ff2a5a2b; ?>
<?php unset($__componentOriginal890ea597e738b5ea559a49d7ff2a5a2b); ?>
<?php endif; ?>
    </main>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH H:\php\herd\isft238\resources\views/layouts/public/page.blade.php ENDPATH**/ ?>