<div class="bg-blue-900 text-white">
    <div class="container mx-auto px-4 py-2 flex justify-between items-center">
        <div class="flex space-x-4">
            <?php $__currentLoopData = $leftItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($item['href']); ?>" class="text-xs md:text-sm flex items-center hover:text-blue-200">
                <i class="fas <?php echo e($item['icon']); ?> mr-2"></i><?php echo e($item['name']); ?>

            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="space-x-4 hidden md:flex">
            <?php $__currentLoopData = $rightItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($item['href']); ?>" class="text-sm hover:text-blue-200 tracking-tighter">
                <?php echo e($item['name']); ?><i class="fas <?php echo e($item['icon']); ?> ml-1"></i>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH H:\php\herd\isft238\resources\views/components/public/banner.blade.php ENDPATH**/ ?>