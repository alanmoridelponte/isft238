<?php if(!$careers->isEmpty()): ?>
<section id="carreras" class="py-16 <?php if($slot->isNotEmpty()): ?> bg-gradient-to-b from-natural-50 via-green-50 to-green-50 <?php else: ?> bg-gradient-to-b from-green-50 via-green-50 to-neutral-50  <?php endif; ?>">
    <div class="mx-auto px-0 md:px-6">
        <?php echo e($slot); ?>

        <div class="grid justify-center grid-cols-1 lg:grid-cols-[repeat(auto-fit,450px)] gap-4 p-2">
            <?php $__currentLoopData = $careers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $career): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal3db096df28e74155e5a1e3a74e6ff8b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3db096df28e74155e5a1e3a74e6ff8b5 = $attributes; } ?>
<?php $component = App\View\Components\Public\CareersListCard::resolve(['career' => $career] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public.careers-list-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Public\CareersListCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3db096df28e74155e5a1e3a74e6ff8b5)): ?>
<?php $attributes = $__attributesOriginal3db096df28e74155e5a1e3a74e6ff8b5; ?>
<?php unset($__attributesOriginal3db096df28e74155e5a1e3a74e6ff8b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3db096df28e74155e5a1e3a74e6ff8b5)): ?>
<?php $component = $__componentOriginal3db096df28e74155e5a1e3a74e6ff8b5; ?>
<?php unset($__componentOriginal3db096df28e74155e5a1e3a74e6ff8b5); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>
<?php /**PATH H:\php\herd\isft238\resources\views/components/public/careers-list.blade.php ENDPATH**/ ?>